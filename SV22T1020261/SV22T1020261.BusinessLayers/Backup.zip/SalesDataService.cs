﻿using SV22T1020261.DataLayers.Interfaces;
using SV22T1020261.DataLayers.SQLServer;
using SV22T1020261.Models.Common;
using SV22T1020261.Models.Sales;

namespace SV22T1020261.BusinessLayers
{
    /// <summary>
    /// Lớp cung cấp các chức năng tác nghiệp liên quan đến bán hàng (Sales)
    /// bao gồm: Order và các chi tiết đơn hàng (OrderDetail)
    /// </summary>
    public static class SalesDataService
    {
        private static readonly IOrderRepository orderDB;

        /// <summary>
        /// Constructor static, được gọi khi lớp được sử dụng lần đầu
        /// </summary>
        static SalesDataService()
        {
            orderDB = new OrderRepository(Configuration.ConnectionString);
        }

        // ================= ORDER =================

        /// <summary>
        /// Tìm kiếm và trả về danh sách đơn hàng có phân trang
        /// </summary>
        public static async Task<PagedResult<OrderViewInfo>> ListOrdersAsync(OrderSearchInput input)
        {
            return await orderDB.ListAsync(input);
        }

        /// <summary>
        /// Lấy thông tin một đơn hàng theo ID
        /// </summary>
        public static async Task<OrderViewInfo?> GetOrderAsync(int orderID)
        {
            return await orderDB.GetAsync(orderID);
        }

        /// <summary>
        /// Thêm mới đơn hàng
        /// </summary>
        public static async Task<int> AddOrderAsync(Order order)
        {
            //TODO: Validate dữ liệu trước khi thêm
            return await orderDB.AddAsync(order);
        }

        /// <summary>
        /// Cập nhật thông tin đơn hàng
        /// </summary>
        public static async Task<bool> UpdateOrderAsync(Order order)
        {
            //TODO: Validate dữ liệu trước khi cập nhật
            return await orderDB.UpdateAsync(order);
        }

        /// <summary>
        /// Xóa đơn hàng theo ID
        /// </summary>
        public static async Task<bool> DeleteOrderAsync(int orderID)
        {
            return await orderDB.DeleteAsync(orderID);
        }

        // ================= ORDER DETAIL =================

        /// <summary>
        /// Lấy danh sách chi tiết mặt hàng trong đơn hàng
        /// </summary>
        public static async Task<List<OrderDetailViewInfo>> ListOrderDetailsAsync(int orderID)
        {
            return await orderDB.ListDetailsAsync(orderID);
        }

        /// <summary>
        /// Lấy thông tin chi tiết của một mặt hàng trong đơn hàng
        /// </summary>
        public static async Task<OrderDetailViewInfo?> GetOrderDetailAsync(int orderID, int productID)
        {
            return await orderDB.GetDetailAsync(orderID, productID);
        }

        /// <summary>
        /// Thêm mặt hàng vào đơn hàng
        /// </summary>
        public static async Task<bool> AddOrderDetailAsync(OrderDetail detail)
        {
            return await orderDB.AddDetailAsync(detail);
        }

        /// <summary>
        /// Cập nhật mặt hàng trong đơn hàng (số lượng, giá)
        /// </summary>
        public static async Task<bool> UpdateOrderDetailAsync(OrderDetail detail)
        {
            return await orderDB.UpdateDetailAsync(detail);
        }

        /// <summary>
        /// Xóa một mặt hàng khỏi đơn hàng
        /// </summary>
        public static async Task<bool> DeleteOrderDetailAsync(int orderID, int productID)
        {
            return await orderDB.DeleteDetailAsync(orderID, productID);
        }
    }
}