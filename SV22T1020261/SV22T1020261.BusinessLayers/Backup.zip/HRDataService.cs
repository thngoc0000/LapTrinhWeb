﻿using SV22T1020261.DataLayers.Interfaces;
using SV22T1020261.DataLayers.SQLServer;
using SV22T1020261.Models.Common;
using SV22T1020261.Models.HR;

namespace SV22T1020261.BusinessLayers
{
    /// <summary>
    /// Lớp cung cấp các chức năng tác nghiệp liên quan đến nhân sự (HR)
    /// bao gồm các xử lý trên Employee
    /// </summary>
    public static class HRDataService
    {
        private static readonly IEmployeeRepository employeeDB;

        /// <summary>
        /// Constructor static, được gọi khi lớp được sử dụng lần đầu
        /// </summary>
        static HRDataService()
        {
            employeeDB = new EmployeeRepository(Configuration.ConnectionString);
        }

        /// <summary>
        /// Tìm kiếm và trả về danh sách nhân viên có phân trang
        /// </summary>
        public static async Task<PagedResult<Employee>> ListEmployeesAsync(PaginationSearchInput input)
        {
            return await employeeDB.ListAsync(input);
        }

        /// <summary>
        /// Lấy thông tin một nhân viên theo ID
        /// </summary>
        public static async Task<Employee?> GetEmployeeAsync(int employeeID)
        {
            return await employeeDB.GetAsync(employeeID);
        }

        /// <summary>
        /// Thêm mới nhân viên
        /// </summary>
        public static async Task<int> AddEmployeeAsync(Employee employee)
        {
            //TODO: Validate dữ liệu trước khi thêm
            return await employeeDB.AddAsync(employee);
        }

        /// <summary>
        /// Cập nhật thông tin nhân viên
        /// </summary>
        public static async Task<bool> UpdateEmployeeAsync(Employee employee)
        {
            //TODO: Validate dữ liệu trước khi cập nhật
            return await employeeDB.UpdateAsync(employee);
        }

        /// <summary>
        /// Xóa nhân viên theo ID
        /// Chỉ xóa khi không có dữ liệu liên quan
        /// </summary>
        public static async Task<bool> DeleteEmployeeAsync(int employeeID)
        {
            if (await employeeDB.IsUsedAsync(employeeID))
                return false;

            return await employeeDB.DeleteAsync(employeeID);
        }

        /// <summary>
        /// Kiểm tra nhân viên có đang được sử dụng không
        /// </summary>
        public static async Task<bool> IsEmployeeUsedAsync(int employeeID)
        {
            return await employeeDB.IsUsedAsync(employeeID);
        }

        /// <summary>
        /// Kiểm tra email của nhân viên có hợp lệ hay không
        /// (Không trùng với nhân viên khác trong hệ thống)
        /// </summary>
        /// <param name="email">Email cần kiểm tra</param>
        /// <param name="employeeID">
        /// = 0: kiểm tra nhân viên mới
        /// <> 0: kiểm tra khi cập nhật nhân viên
        /// </param>
        public static async Task<bool> ValidateEmployeeEmailAsync(string email, int employeeID = 0)
        {
            return await employeeDB.ValidateEmailAsync(email, employeeID);
        }
    }
}