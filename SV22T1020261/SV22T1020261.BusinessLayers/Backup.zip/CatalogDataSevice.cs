﻿using SV22T1020261.DataLayers.Interfaces;
using SV22T1020261.DataLayers.SQLServer;
using SV22T1020261.Models.Catalog;
using SV22T1020261.Models.Common;

namespace SV22T1020261.BusinessLayers
{
    /// <summary>
    /// Lớp cung cấp các chức năng tác nghiệp liên quan đến danh mục (Catalog)
    /// bao gồm: Category, Product và các thông tin liên quan đến Product
    /// (Attribute, Photo)
    /// </summary>
    public static class CatalogDataService
    {
        private static readonly IGenericRepository<Category> categoryDB;
        private static readonly IProductRepository productDB;

        /// <summary>
        /// Constructor static được gọi khi lớp được sử dụng lần đầu
        /// </summary>
        static CatalogDataService()
        {
            categoryDB = new CategoryRepository(Configuration.ConnectionString);
            productDB = new ProductRepository(Configuration.ConnectionString);
        }

        // ================= CATEGORY =================

        /// <summary>
        /// Tìm kiếm và trả về danh sách loại hàng (Category) có phân trang
        /// </summary>
        public static async Task<PagedResult<Category>> ListCategoriesAsync(PaginationSearchInput input)
        {
            return await categoryDB.ListAsync(input);
        }

        /// <summary>
        /// Lấy thông tin một loại hàng theo ID
        /// </summary>
        public static async Task<Category?> GetCategoryAsync(int categoryID)
        {
            return await categoryDB.GetAsync(categoryID);
        }

        /// <summary>
        /// Thêm mới loại hàng
        /// </summary>
        public static async Task<int> AddCategoryAsync(Category category)
        {
            //TODO: Validate dữ liệu
            return await categoryDB.AddAsync(category);
        }

        /// <summary>
        /// Cập nhật loại hàng
        /// </summary>
        public static async Task<bool> UpdateCategoryAsync(Category category)
        {
            //TODO: Validate dữ liệu
            return await categoryDB.UpdateAsync(category);
        }

        /// <summary>
        /// Xóa loại hàng (chỉ xóa khi không có dữ liệu liên quan)
        /// </summary>
        public static async Task<bool> DeleteCategoryAsync(int categoryID)
        {
            if (await categoryDB.IsUsedAsync(categoryID))
                return false;

            return await categoryDB.DeleteAsync(categoryID);
        }

        /// <summary>
        /// Kiểm tra loại hàng có đang được sử dụng không
        /// </summary>
        public static async Task<bool> IsCategoryUsedAsync(int categoryID)
        {
            return await categoryDB.IsUsedAsync(categoryID);
        }

        // ================= PRODUCT =================

        /// <summary>
        /// Tìm kiếm và trả về danh sách mặt hàng có phân trang
        /// </summary>
        public static async Task<PagedResult<Product>> ListProductsAsync(ProductSearchInput input)
        {
            return await productDB.ListAsync(input);
        }

        /// <summary>
        /// Lấy thông tin một mặt hàng theo ID
        /// </summary>
        public static async Task<Product?> GetProductAsync(int productID)
        {
            return await productDB.GetAsync(productID);
        }

        /// <summary>
        /// Thêm mới mặt hàng
        /// </summary>
        public static async Task<int> AddProductAsync(Product product)
        {
            //TODO: Validate dữ liệu
            return await productDB.AddAsync(product);
        }

        /// <summary>
        /// Cập nhật mặt hàng
        /// </summary>
        public static async Task<bool> UpdateProductAsync(Product product)
        {
            //TODO: Validate dữ liệu
            return await productDB.UpdateAsync(product);
        }

        /// <summary>
        /// Xóa mặt hàng (chỉ xóa khi không có dữ liệu liên quan)
        /// </summary>
        public static async Task<bool> DeleteProductAsync(int productID)
        {
            if (await productDB.IsUsedAsync(productID))
                return false;

            return await productDB.DeleteAsync(productID);
        }

        /// <summary>
        /// Kiểm tra mặt hàng có đang được sử dụng không
        /// </summary>
        public static async Task<bool> IsProductUsedAsync(int productID)
        {
            return await productDB.IsUsedAsync(productID);
        }

        // ================= PRODUCT ATTRIBUTE =================

        /// <summary>
        /// Lấy danh sách thuộc tính của mặt hàng
        /// </summary>
        public static async Task<List<ProductAttribute>> ListAttributesAsync(int productID)
        {
            return await productDB.ListAttributesAsync(productID);
        }

        /// <summary>
        /// Lấy thông tin một thuộc tính
        /// </summary>
        public static async Task<ProductAttribute?> GetAttributeAsync(long attributeID)
        {
            return await productDB.GetAttributeAsync(attributeID);
        }

        /// <summary>
        /// Thêm thuộc tính cho mặt hàng
        /// </summary>
        public static async Task<long> AddAttributeAsync(ProductAttribute attribute)
        {
            return await productDB.AddAttributeAsync(attribute);
        }

        /// <summary>
        /// Cập nhật thuộc tính của mặt hàng
        /// </summary>
        public static async Task<bool> UpdateAttributeAsync(ProductAttribute attribute)
        {
            return await productDB.UpdateAttributeAsync(attribute);
        }

        /// <summary>
        /// Xóa thuộc tính của mặt hàng
        /// </summary>
        public static async Task<bool> DeleteAttributeAsync(long attributeID)
        {
            return await productDB.DeleteAttributeAsync(attributeID);
        }

        // ================= PRODUCT PHOTO =================

        /// <summary>
        /// Lấy danh sách ảnh của mặt hàng
        /// </summary>
        public static async Task<List<ProductPhoto>> ListPhotosAsync(int productID)
        {
            return await productDB.ListPhotosAsync(productID);
        }

        /// <summary>
        /// Lấy thông tin một ảnh của mặt hàng
        /// </summary>
        public static async Task<ProductPhoto?> GetPhotoAsync(long photoID)
        {
            return await productDB.GetPhotoAsync(photoID);
        }

        /// <summary>
        /// Thêm ảnh cho mặt hàng
        /// </summary>
        public static async Task<long> AddPhotoAsync(ProductPhoto photo)
        {
            return await productDB.AddPhotoAsync(photo);
        }

        /// <summary>
        /// Cập nhật ảnh của mặt hàng
        /// </summary>
        public static async Task<bool> UpdatePhotoAsync(ProductPhoto photo)
        {
            return await productDB.UpdatePhotoAsync(photo);
        }

        /// <summary>
        /// Xóa ảnh của mặt hàng
        /// </summary>
        public static async Task<bool> DeletePhotoAsync(long photoID)
        {
            return await productDB.DeletePhotoAsync(photoID);
        }
    }
}