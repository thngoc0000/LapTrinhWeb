﻿using SV22T1020261.DataLayers.Interfaces;
using SV22T1020261.DataLayers.SQLServer;
using SV22T1020261.Models.Common;
using SV22T1020261.Models.Partner;
using System.Threading.Tasks;

namespace SV22T1020261.BusinessLayers
{
    /// <summary>
    /// Lớp cung cấp các chức năng tác nghiệp liên quan đến đối tác của hệ thống
    /// bao gồm: Customer, Supplier, Shipper
    /// </summary>
    public static class PartnerDataService
    {
        private static readonly IGenericRepository<Supplier> supplierDB;
        private static readonly IGenericRepository<Shipper> shipperDB;
        private static readonly ICustomerRepository customerDB;

        /// <summary>
        /// Constructor của lớp static ko có tham số,
        /// được gọi tự động khi có thành phần nào đó truy cập vào lớp này lần đầu tiên
        /// </summary>
        static PartnerDataService()
        {
            supplierDB = new SupplierRepository(Configuration.ConnectionString);
            shipperDB = new ShipperRepository(Configuration.ConnectionString);
            customerDB = new CustomerRepository(Configuration.ConnectionString);
        }

        //== CÁC CHỨC NĂNG NGHIỆP VỤ LIÊN QUAN ĐẾN SUPPLIER

        /// <summary>
        /// Tìm kiếm và trả về danh sách nhà cung cấp dưới dạng phân trang
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static async Task<PagedResult<Supplier>> ListSuppliersAsync(PaginationSearchInput input)
        {
            return await supplierDB.ListAsync(input);
        }

        /// <summary>
        /// Lấy thông tin của 1 nhà cung cấp dựa vào mã nhà cung cấp
        /// </summary>
        /// <param name="supplierID"></param>
        /// <returns></returns>
        public static async Task<Supplier?> GetSupplierAsync(int supplierID)
        {
            return await supplierDB.GetAsync(supplierID);
        }

        /// <summary>
        /// Bổ sung nhà cung cấp
        /// </summary>
        /// <param name="data"></param>
        /// <returns>Mã nhà cung cấp được bổ sung</returns>
        public static async Task<int> AddSupplierAsync(Supplier supplier)
        {
            //TODO: Kiểm tra tính hợp lệ của dữ liệu trước khi bổ sung
            return await supplierDB.AddAsync(supplier);
        }

        public static async Task<bool> UpdateSupplierAsync(Supplier supplier)
        {
            //TODO: Kiểm tra tính hợp lệ của dữ liệu trước khi cập nhật
            return await supplierDB.UpdateAsync(supplier);
        }

        /// <summary>
        /// Delete một nhà cung cấp dựa vào mã nhà cung cấp
        /// Kiểm tra xem nhà cung cấp có mặt hàng nào liên quan hay không (kiểm tra xem có được phép xoá không)
        /// </summary>
        /// <param name="supplierID"></param>
        /// <returns></returns>
        public static async Task<bool> DeleteSupplierAsync(int supplierID)
        {
            if (await supplierDB.IsUsedAsync(supplierID))
            {
                return false;
            }
            return await supplierDB.DeleteAsync(supplierID);
        }

        /// <summary>
        /// Kiểm tra xem một nhà cung cấp có mặt hàng nào liên quan hay không
        /// (kiểm tra xem có được phép xoá không)
        /// </summary>
        /// <param name="supplierID"></param>
        /// <returns></returns>
        public static async Task<bool> IsSupplierUsedAsync(int supplierID)
        {
            return await supplierDB.IsUsedAsync(supplierID);
        }

        //== CÁC CHỨC NĂNG NGHIỆP VỤ LIÊN QUAN ĐẾN SHIPPER

        /// <summary>
        /// Tìm kiếm và trả về danh sách shipper dưới dạng phân trang
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static async Task<PagedResult<Shipper>> ListShippersAsync(PaginationSearchInput input)
        {
            return await shipperDB.ListAsync(input);
        }

        /// <summary>
        /// Lấy thông tin của 1 shipper theo mã shipper
        /// </summary>
        /// <param name="shipperID"></param>
        /// <returns></returns>
        public static async Task<Shipper?> GetShipperAsync(int shipperID)
        {
            return await shipperDB.GetAsync(shipperID);
        }

        /// <summary>
        /// Bổ sung shipper mới
        /// </summary>
        /// <param name="shipper"></param>
        /// <returns>Mã shipper được bổ sung</returns>
        public static async Task<int> AddShipperAsync(Shipper shipper)
        {
            //TODO: Kiểm tra tính hợp lệ dữ liệu trước khi bổ sung
            return await shipperDB.AddAsync(shipper);
        }

        /// <summary>
        /// Cập nhật thông tin shipper
        /// </summary>
        /// <param name="shipper"></param>
        /// <returns></returns>
        public static async Task<bool> UpdateShipperAsync(Shipper shipper)
        {
            //TODO: Kiểm tra tính hợp lệ dữ liệu trước khi cập nhật
            return await shipperDB.UpdateAsync(shipper);
        }

        /// <summary>
        /// Xóa shipper theo mã shipper
        /// Kiểm tra xem shipper có liên quan đến đơn hàng hay không
        /// </summary>
        /// <param name="shipperID"></param>
        /// <returns></returns>
        public static async Task<bool> DeleteShipperAsync(int shipperID)
        {
            if (await shipperDB.IsUsedAsync(shipperID))
            {
                return false;
            }
            return await shipperDB.DeleteAsync(shipperID);
        }

        /// <summary>
        /// Kiểm tra shipper có đang được sử dụng hay không
        /// </summary>
        /// <param name="shipperID"></param>
        /// <returns></returns>
        public static async Task<bool> IsShipperUsedAsync(int shipperID)
        {
            return await shipperDB.IsUsedAsync(shipperID);
        }


        //== CÁC CHỨC NĂNG NGHIỆP VỤ LIÊN QUAN ĐẾN CUSTOMER

        /// <summary>
        /// Tìm kiếm và trả về danh sách khách hàng dưới dạng phân trang
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static async Task<PagedResult<Customer>> ListCustomersAsync(PaginationSearchInput input)
        {
            return await customerDB.ListAsync(input);
        }

        /// <summary>
        /// Lấy thông tin của 1 khách hàng theo mã khách hàng
        /// </summary>
        /// <param name="customerID"></param>
        /// <returns></returns>
        public static async Task<Customer?> GetCustomerAsync(int customerID)
        {
            return await customerDB.GetAsync(customerID);
        }

        /// <summary>
        /// Bổ sung khách hàng mới
        /// </summary>
        /// <param name="customer"></param>
        /// <returns>Mã khách hàng được bổ sung</returns>
        public static async Task<int> AddCustomerAsync(Customer customer)
        {
            //TODO: Kiểm tra tính hợp lệ dữ liệu trước khi bổ sung
            return await customerDB.AddAsync(customer);
        }

        /// <summary>
        /// Cập nhật thông tin khách hàng
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        public static async Task<bool> UpdateCustomerAsync(Customer customer)
        {
            //TODO: Kiểm tra tính hợp lệ dữ liệu trước khi cập nhật
            return await customerDB.UpdateAsync(customer);
        }

        /// <summary>
        /// Xóa khách hàng theo mã khách hàng
        /// Kiểm tra xem khách hàng có đơn hàng liên quan hay không
        /// </summary>
        /// <param name="customerID"></param>
        /// <returns></returns>
        public static async Task<bool> DeleteCustomerAsync(int customerID)
        {
            if (await customerDB.IsUsedAsync(customerID))
            {
                return false;
            }
            return await customerDB.DeleteAsync(customerID);
        }

        /// <summary>
        /// Kiểm tra khách hàng có đang được sử dụng hay không
        /// </summary>
        /// <param name="customerID"></param>
        /// <returns></returns>
        public static async Task<bool> IsCustomerUsedAsync(int customerID)
        {
            return await customerDB.IsUsedAsync(customerID);
        }

        /// <summary>
        /// Kiểm tra email của khách hàng có hợp lệ hay không?
        /// (Email hợp lệ nếu email không trùng với email của khách hàng khác đã tồn tại trong hệ thống)
        /// </summary>
        /// <param name="email"></param>
        /// <param name="customerID">
        /// Nếu = 0: Kiểm tra email của khách hàng mới
        /// Nếu <> 0: Kiểm tra email của khách hàng có mã là <paramref name="customerID"/></param>
        /// <returns></returns>
        public static async Task<bool> ValidateCustomerEmailAsync(string email, int customerID = 0)
        {
            return await customerDB.ValidateEmailAsync(email, customerID);
        }
    }
}